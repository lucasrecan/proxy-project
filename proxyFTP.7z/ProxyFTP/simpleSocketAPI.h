#ifndef _SIMPLESOCKETAPI_H
#define _SIMPLESOCKETAPI_H

int connect2Server(const char *serverName, const char *port, int *descSock);

#endif